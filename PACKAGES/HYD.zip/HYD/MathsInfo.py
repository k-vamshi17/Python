#MathsInfo.py<---File Name and Acts as Module Name
PI=3.14
E=2.71 # Here PI and E are called Global Variables
