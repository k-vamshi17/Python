#MulExcept.py<--File Name and Module Name
class ZeroError(Exception):pass
class NegNumError(Exception):pass
