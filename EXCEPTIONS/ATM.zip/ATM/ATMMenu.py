#ATMMenu.py
def menu():
    print("*"*50)
    print("\tATM OR Funds Transfer Operations")
    print("*" * 50)
    print("\t1.Deposit")
    print("\t2.Withdraw")
    print("\t3.Bal Enq")
    print("\t4.Exit")
    print("*" * 50)